package com.tripify.hotels.service.kafka.model;

import java.time.LocalDate;
import java.util.List;

public record SearchContextEvent(
        String origin,
        String destination,
        LocalDate dateFrom,
        LocalDate dateTo,
        String currency,
        int adults,
        Integer children,
        Long budget,
        List<String> filters
) {
}
