package com.tripify.hotels.service.service;

import java.time.Instant;
import java.time.LocalDate;
import java.util.UUID;

import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tripify.hotels.generated.model.HotelDetails;
import com.tripify.hotels.service.config.property.KafkaTopicsProperties;
import com.tripify.hotels.service.exception.HotelPackViewPublishException;
import com.tripify.hotels.service.kafka.model.PackHeadersEvent;
import com.tripify.hotels.service.kafka.model.PackViewEvent;
import com.tripify.hotels.service.kafka.model.SearchContextEvent;
import com.tripify.hotels.service.kafka.model.UserType;
import com.tripify.hotels.service.model.outbox.AggregateType;
import com.tripify.hotels.service.model.outbox.OutboxEvent;
import com.tripify.hotels.service.model.outbox.OutboxEventStatus;
import com.tripify.hotels.service.model.outbox.OutboxEventType;
import com.tripify.hotels.service.repository.contract.OutboxEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class HotelPackViewPublisher {

    private final OutboxEventRepository outboxEventRepository;
    private final KafkaTopicsProperties kafkaTopics;
    private final ObjectMapper objectMapper;

    public void publishHotelDetailView(
            PackHeadersEvent headers,
            SearchContextEvent searchContext,
            HotelDetails hotel
    ) {
        JsonNode model = objectMapper.valueToTree(hotel);
        PackViewEvent event = new PackViewEvent(
                Instant.now(),
                headers,
                searchContext,
                model
        );

        String payload = serialize(event);
        Instant now = Instant.now();

        outboxEventRepository.saveEvent(new OutboxEvent(
                UUID.randomUUID(),
                AggregateType.HOTEL_PACK_VIEW,
                headers.generationId(),
                OutboxEventType.HOTEL_PACK_VIEWED,
                kafkaTopics.hotelsPackViewed(),
                payload,
                OutboxEventStatus.PENDING,
                0,
                null,
                now,
                now,
                null
        ));
    }

    public static PackHeadersEvent toHeaders(
            UserType userType,
            String userId,
            String anonymousId,
            String generationId,
            int packRevision,
            String generationMode,
            String requestId,
            Integer serviceRevision
    ) {
        return new PackHeadersEvent(
                userType,
                userId,
                anonymousId,
                generationId,
                packRevision,
                generationMode,
                requestId,
                serviceRevision
        );
    }

    public static SearchContextEvent toSearchContext(
            String country,
            String city,
            LocalDate checkIn,
            LocalDate checkOut,
            String currency,
            int adults,
            Integer children,
            Long budget,
            List<String> filters
    ) {
        return new SearchContextEvent(
                country,
                city,
                checkIn,
                checkOut,
                currency,
                adults,
                children,
                budget,
                filters == null ? List.of() : List.copyOf(filters)
        );
    }

    private String serialize(PackViewEvent event) {
        try {
            return objectMapper.writeValueAsString(event);
        } catch (JsonProcessingException exception) {
            throw new HotelPackViewPublishException(
                    "Failed to serialize hotel pack view event for generationId="
                            + event.headers().generationId(),
                    exception
            );
        }
    }
}
